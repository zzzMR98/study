// system
#include <string>
#include <memory>

// ROS
#include <ros/ros.h>

// OpenCV
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>

// custom
#include "iv_slam_ros_msgs/TraversableArea.h"

using namespace std;

void traversable_area_callback(
        const iv_slam_ros_msgs::TraversableArea::ConstPtr traversable_area_msg) {
    ROS_INFO_ONCE("visualize_traversable_area_node callback running");
    bool traversable_area_empty = false;
    if (traversable_area_msg->width == 0 || traversable_area_msg->height == 0)
        traversable_area_empty = true;
    if (!traversable_area_empty) {
        traversable_area_empty = true;
        for (int i=0; i<traversable_area_msg->cells.size(); i++) {
            if (traversable_area_msg->cells[i] != 0) {
                traversable_area_empty = false;
                break;
            }
        }
    }
    if (traversable_area_empty) {
        ROS_WARN_THROTTLE(5, "Empty map!");
        if (traversable_area_msg->width == 0 || traversable_area_msg->height == 0) {
            printf("map size zero\n");
            return;
        }
    }
    cv::Mat img = cv::Mat::zeros(cv::Size(traversable_area_msg->width, traversable_area_msg->height), CV_8UC3);
    for (int i=0; i<traversable_area_msg->height; i++) {
        for (int j=0; j<traversable_area_msg->width; j++) {
            switch (traversable_area_msg->cells[i*traversable_area_msg->width+j])
            {
            case 1:
                img.at<cv::Vec3b>(i,j)[0] = 0;
                img.at<cv::Vec3b>(i,j)[1] = 255;
                img.at<cv::Vec3b>(i,j)[2] = 0;
                break;
            case 2:
                img.at<cv::Vec3b>(i,j)[0] = 255;
                img.at<cv::Vec3b>(i,j)[1] = 255;
                img.at<cv::Vec3b>(i,j)[2] = 255;
                break;
            case 4:
                img.at<cv::Vec3b>(i,j)[0] = 0;
                img.at<cv::Vec3b>(i,j)[1] = 0;
                img.at<cv::Vec3b>(i,j)[2] = 255;
                break;
            default:
                break;
            }
        }
    }
    cv::imshow("visualize_traversable_area_node", img);
    cv::waitKey(1);
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "visualize_traversable_area_node");
    ros::start();
    ROS_INFO("entering visualize_traversable_area_node.");
    ros::NodeHandle nh;
    ros::NodeHandle pnh("~");
    string traversable_area_topic;
    pnh.param<string>("traversable_area_topic", traversable_area_topic, "final_traversable_area_topic");
    ros::Subscriber traversable_area_sub = nh.subscribe<iv_slam_ros_msgs::TraversableArea>(traversable_area_topic, 1, traversable_area_callback);
    ROS_INFO("visualize_traversable_area_node start.");
    ros::spin();

}