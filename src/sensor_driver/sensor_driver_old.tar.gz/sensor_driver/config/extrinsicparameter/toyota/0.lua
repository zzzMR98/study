
options={
  ip = "192.168.0.2",
  port = 2368,
  lasernum = 64,
  x_offset = 0,
  y_offset = 1,
  z_offset = 2.14,
  x_angle = -2.6254,
  y_angle = 0.3288,
  z_angle = 0,
}
return options
