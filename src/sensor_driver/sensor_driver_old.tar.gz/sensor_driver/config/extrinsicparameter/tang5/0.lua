
options={
	ip = "192.168.3.202",
	port = 9902,
	lasernum = 32,
	x_offset = 0,
	y_offset = 1,
	z_offset = 2.1,
	x_angle = 0,
	y_angle = 0,
	z_angle = 0,
}
return options
