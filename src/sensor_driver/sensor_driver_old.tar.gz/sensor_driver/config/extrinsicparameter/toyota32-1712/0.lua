
options={
  ip = "192.168.0.201",
  port = 9901,
  lasernum = 32,
  x_angle = 0.5618,
  y_angle = -3.3928,
  z_angle = -123.4360,
  x_offset = -0.6226,
  y_offset = 1.3999,
  z_offset = 2.0945,

}
return options