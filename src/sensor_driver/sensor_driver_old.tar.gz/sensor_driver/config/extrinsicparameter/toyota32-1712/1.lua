
options={
	ip = "192.168.0.202",
	port = 9902,
	lasernum = 32,
	x_angle = -0.6786,
	y_angle = -3.3807,
	z_angle = -92.3616,
	x_offset = 0.622,
	y_offset = 1.4,
	z_offset = 2.1,

}
return options
