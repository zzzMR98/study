
options={
  ip = "192.168.3.201",
  port = 9901,
  lasernum = 32,
  x_offset = 0,
  y_offset = 1,
  z_offset = 2.3367,
  x_angle = -2.7722393,
  y_angle = -0.1062172,
  z_angle = -10,
  calibration_file = "",
  model = "velodyne",
}
return options
