
options={
	ip = "192.168.1.201",
	port = 2368,
	lasernum = 32,
	x_offset = 0,
	y_offset = 1.2,
	z_offset = 1.98,
	x_angle = 0,
	y_angle = 0,
	z_angle = 1.3,
}
return options
