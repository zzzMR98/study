
options={
	ip = "192.168.3.202",
	port = 9902,
	lasernum = 32,
	x_angle = -0.6936,
	y_angle = -3.1294,
	z_angle =  -88.4861,
	x_offset = 0.6231,
	y_offset = 1.4825,
	z_offset =  2.0003,

}
return options
