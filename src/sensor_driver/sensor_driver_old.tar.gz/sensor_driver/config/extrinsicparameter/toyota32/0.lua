
options={
  ip = "192.168.3.201",
  port = 9901,
  lasernum = 32,
  x_angle =  0.8913,
  y_angle = -3.9840,
  z_angle = -89.5892,
  x_offset = -0.6099,
  y_offset = 1.4833,
  z_offset = 2.0242,

}
return options
