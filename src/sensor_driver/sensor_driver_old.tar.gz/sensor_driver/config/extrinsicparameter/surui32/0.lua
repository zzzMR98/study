
options={
  ip = "192.168.1.202",
  port = 9902,
  lasernum = 32,
  x_offset = 0,
  y_offset = 0,
  z_offset = 2,
  x_angle = -2.4217,
  y_angle = 1.4820,
  z_angle = 2.6525,
  calibration_file = "",
  model = "velodyne",
}
return options
