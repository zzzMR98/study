
options={
	ip = "192.168.3.202",
	port = 9902,
	lasernum = 32,
	x_angle = -0.4604,
	y_angle = -0.9584,
	z_angle =  -88.4676,
	x_offset = 0.6165,
	y_offset = 1.4,
	z_offset = 2.2,

}
return options
