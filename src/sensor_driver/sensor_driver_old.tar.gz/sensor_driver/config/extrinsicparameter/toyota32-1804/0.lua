
options={
  ip = "192.168.3.201",
  port = 9901,
  lasernum = 32,
  x_angle =  1.0672,
  y_angle = -1.8035,
  z_angle = -89.6295,
  x_offset = -0.6165,
  y_offset = 1.4000,
  z_offset = 2.2201,

}
return options
